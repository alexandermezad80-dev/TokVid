# TokVid · Bloque FEED (Para ti y comentarios)

Este bloque es **independiente** del bloque de Perfil/Amigos. Pantalla de referencia: **390 × 844 dp**. Medidas en dp. Referencias: `1-Feed.png`, `2-Comentarios.png`, `3-Comentarios-teclado.png`, `Feed-medidas.png` (con cotas) y `referencia/*.html` (CSS exacto).
Todas las funciones del Feed se quedan **exactamente como ya funcionan**; este bloque solo cambia la presentación.

**H = alto de la ventana disponible.** Todo se calcula con H para que sirva en cualquier teléfono. Arriba y abajo se usa el safe area real del sistema (barra de estado arriba; botones o gestos abajo). Colores y fuente: los de la app.

## Estado 1 · Feed
- Video a pantalla completa, desde arriba del todo hasta la barra inferior. Alto = H − 64 − safe area inferior. 9:16 con recorte, fondo negro. Degradados para legibilidad: arriba 130 y abajo 300.
- Pestañas "Para ti" / "Siguiendo": fila de 48 debajo de la barra de estado, texto 17; búsqueda de 44 × 44 a 8 del borde derecho.
- Columna de acciones a la derecha: margen 12, ancho 48, borde inferior 16 sobre la barra inferior. Avatar 48 con aro degradado, Me gusta, Comentarios, Compartir y Guardar; íconos de 32, contadores 12 bold, separación 18.
- Datos del video a la izquierda: margen 16, borde inferior 16 sobre la barra, ancho máximo = ancho − 16 − 12 − 48 − 12. Avatar 40 + @usuario 15 bold (una línea, puntos suspensivos) + botón **Siguiendo** (alto 28, contorno de 1.5 con degradado cyan a rosa) **junto al nombre, nunca encima de la columna de acciones**. Descripción 13 / 18, máximo 2 líneas; sonido 12 con ícono de 14. Separación 8.
- Barra inferior: 64 + safe area inferior.

## Estado 2 · Comentarios abiertos
- **El video se minimiza UNA sola vez: al abrir los comentarios.** No existe ningún otro tamaño reducido del video (ni con teclado, ni al escribir). Si ves un segundo tamaño de video en cualquier referencia, es un error y no se usa.
- **Video minimizado: alto = 36 % de H** (304 en 844), **ancho = alto × 9/16** (171), centrado, a 8 debajo de la barra de estado, radio 20, borde 1. Botón de expandir de 36 × 36 dentro del marco, arriba a la derecha (radio 12, fondo negro 45 %). **Este tamaño no cambia nunca.**
- **La hoja tapa la barra inferior y llega hasta la zona de seguridad.** Su borde superior queda en **safe area superior + 8 + video + 8** (356 en 844) y su borde inferior en el borde de la pantalla. La barra inferior no se ve.
  - Con botones de Android: el fondo de la hoja llega hasta abajo y la barra de escritura queda justo encima de los botones.
  - Con gestos o sin botones: la hoja ocupa hasta el borde, sumando solo el pequeño espacio de gestos.
- Radio superior 20, fondo `#15151B` con un tinte rosa muy suave arriba, línea superior de 1. Barra de arrastre 36 × 4 a 6 del borde.
- **Cabecera: 44.** Chip "3 comentarios" a 16 del borde (alto 34, radio 12, padding horizontal 14, texto 15 bold, fondo degradado cyan a rosa al 18 %, borde 1). Cerrar de 44 × 44 a 8 del borde derecho.
- **Lista con scroll** (ocupa todo el espacio entre la cabecera y la barra de escritura), padding horizontal 16:
  - Comentario: padding vertical 7 (**14 entre comentarios**), avatar 32, separación 12.
  - Línea 1 (alto 16): @usuario 13 semibold secundario + "· 10h" 12. Línea 2: texto 15 / 20. Línea 3 (a 6): **"Responder" 12 semibold y "Ver respuestas (n)" 12 semibold cyan en la misma línea**, separación 16.
  - Columna derecha de 32: los tres puntos arriba, corazón de 22 y contador 11.5.
  - Respuestas desplegadas: sangría de 44, avatar de 24, 8 entre respuestas.
- **Barra de escritura: 52** más safe area inferior. Campo de 44 de alto, radio 22, borde 1, padding 8, con avatar 28, "Agregar un comentario…" 14 y flecha de enviar de 24.

## Estado 3 · Teclado sobre la hoja de comentarios
- **El teclado NO empuja nada hacia arriba y NO provoca otra minimización.** Se pone **encima de la hoja de comentarios**, como una capa, junto con la barra de escritura.
- **No cambia nada:** ni el video (sigue en 36 % de H y en el mismo lugar), ni el tamaño de la hoja (sigue con el mismo alto de 488 en 844), ni su borde superior.
- **Lo único que se mueve es la barra de escritura:** sube exactamente el alto del teclado y queda **pegada al borde superior del teclado**, sin hueco, sin safe area inferior (el teclado ya cubre esa zona). Se dibuja encima de la lista, con el mismo fondo de la hoja y una línea superior de 1.
- La lista de comentarios no se redimensiona ni se reacomoda: queda debajo del teclado y de la barra. Para poder llegar a todos los comentarios, la lista suma un espacio al final igual al alto del teclado + 52 mientras el teclado está abierto.
- La barra de escritura puede crecer hacia arriba hasta 3 líneas (cubriendo más lista). Contador "0/300" 11.5 dentro del campo, antes de la flecha.
- Al cerrar el teclado, la barra baja a su lugar (estado 2) y el contenido queda exactamente como estaba.

## Por qué se encogía y rebotaba (y cómo evitarlo)
La causa más probable es que **el teclado cambia el tamaño de la ventana (o empuja el contenido) y, a la vez, la app anima el video**: se pelean y se ve el rebote. Para que quede exacto:
1. **Que el teclado no redimensione ni empuje la pantalla del Feed.** Si esta pantalla tiene el ajuste automático del teclado del sistema (adjustResize o adjustPan), desactivarlo aquí (adjustNothing) y manejar el teclado con sus insets solo para mover la barra de escritura.
2. El video de comentarios tiene **un solo tamaño** (36 % de H). Nunca se calcula a partir de la altura "a medias" mientras sube el teclado.
3. La hoja tiene **un solo tamaño**; el teclado se dibuja sobre ella.
4. Para la barra de escritura, una sola animación **de 220 ms con desaceleración suave, sin resorte ni rebote**, que siga el movimiento del teclado.
5. No recrear el reproductor: escalar o recortar el mismo reproductor, siempre 9:16 con fondo negro.
6. Transiciones solo entre estados: Feed → Comentarios → Comentarios con teclado, y de regreso.

## Instrucción para pegarle a tu agente
Trabaja solo este bloque (Feed y comentarios). Implementa la presentación del Feed y de los comentarios siguiendo exactamente `TokVid-medidas-feed.md`, con los `*.png` y el CSS de `referencia/*.html` como referencia. Todas las funciones existentes se quedan como están; solo cambia la presentación. La hoja de comentarios debe tapar la barra inferior y llegar hasta la zona de seguridad real del teléfono (botones o gestos); el video minimizado mide el 36 % del alto, siempre igual, y el teclado nunca lo redimensiona ni empuja la pantalla: se pone encima de la hoja, que no cambia de tamaño, y solo sube la barra de escritura pegada al teclado. Una sola animación de 220 ms sin rebote; no recrees el reproductor. El botón Siguiendo va junto al nombre, nunca encima de la columna de acciones. Usa los colores y la fuente reales de la app. Solo cambios de interfaz: no modifiques Supabase, migraciones, políticas ni lógica de datos. Antes de editar dime qué archivos vas a tocar y, al terminar, compara cada estado con su imagen y lista las diferencias.
