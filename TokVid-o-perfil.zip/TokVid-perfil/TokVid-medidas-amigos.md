# TokVid · Medidas de Amigos

Pantalla de referencia: **390 × 844 dp**. Medidas en dp. Referencias: `5-Amigos.png`, `5-Amigos-medidas.png` (con cotas) y `referencia/5-Amigos.html` (CSS exacto). Las reglas de adaptación (320–412+ dp, letra grande, safe area) están al final de `TokVid-medidas-perfil.md` y aplican igual aquí.

## Estructura (de arriba hacia abajo)
1. **Safe area superior:** barra de estado real del sistema (en el mockup son 36). Nada de botones al nivel de la cámara.
2. **Cabecera:** alto 52. Flecha de regreso de 44 × 44 pegada a la izquierda (8 de margen, ícono de 22). Título "Amigos" centrado, 18 extra-bold. Subtítulo "Se siguen mutuamente" debajo, 11.5, color secundario.
3. **Pestañas** (Amigos, Seguidores, Siguiendo): 3 iguales, alto 44, línea inferior de 1 en todo el ancho. Ícono 20 + texto 13 bold, separación 6. La activa va en rosa con línea de 2 debajo.
4. **Buscador:** margen 12 arriba / 16 a los lados / 4 abajo. Alto 40, radio 20, padding horizontal 16. Ícono de 20, separación 10, texto "Buscar amigos" 13.5.
5. **Lista** (ocupa todo el espacio restante, con scroll):
   - Fila de **64** de alto, padding horizontal **16**, separación interna **12**, línea inferior de 1.
   - Avatar circular de **44**.
   - Nombre 15 bold y usuario (@) 12.5 regular en color secundario. Una sola línea con puntos suspensivos si no caben.
   - Botón **Siguiendo** a la derecha: alto **32**, padding horizontal 12, radio 16, texto 12.5 bold rosa, check de 14, separación 5. **Contorno de 1.5 con degradado** de cyan a rosa (izquierda a derecha), interior del color del fondo.
   - La última fila visible puede quedar cortada por la barra inferior (scroll).
6. **Barra inferior:** alto **64 más el safe area inferior** (botones o gestos). Línea superior de 1. Cinco ítems iguales: Inicio, Amigos (activo, rosa), botón +, Mensajes, Perfil. Ícono 20 y etiqueta 10.5 semibold, separación 3, etiqueta en una sola línea. El botón + mide **52 × 34**, radio 12, degradado de cyan a rosa, + blanco de 22.

## Colores del mockup (usar los tokens de la app si ya existen)
Fondo `#000`, barra inferior `#07070A`, superficie del buscador `#101018`, líneas `#1E1E28` y `#14141C`, texto `#FFFFFF`, secundario `#8A8A9A`, rosa `#FF2D8A` / `#FF0A78`, cyan `#00E5FF`.

## Comportamiento
- Tocar una pestaña cambia la lista (Amigos, Seguidores, Siguiendo).
- Los nombres y fotos del mockup son de ejemplo; la lista viene de los datos reales.
- Solo cambios de interfaz: no modificar Supabase, migraciones, políticas ni lógica de datos.
