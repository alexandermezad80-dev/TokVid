# TokVid · Medidas de Perfil, Editar perfil y Modal de foto

Pantalla de referencia: **390 × 844 dp**. Todas las medidas están en dp (px lógicos).
Los archivos `referencia/*.html` tienen el CSS exacto de cada pantalla; las imágenes PNG son la referencia visual.

## Reglas generales
- Zona superior: usar el **safe area / status bar real del sistema** (en el mockup son 36 dp). Ningún botón debe quedar al nivel de la cámara ni de los íconos del teléfono. No dibujar cámara ni barra de navegación falsas.
- Botones táctiles de íconos: **44 × 44**, ícono de **22**, trazo de **1.8**.
- Zona inferior: la barra inferior mide **64 dp más el safe area inferior del sistema** (botones <, O, ||| o gestos de Android). La barra se pinta sobre ese espacio con su mismo fondo, pero los íconos quedan siempre por encima de los botones del teléfono. Nunca poner un alto fijo de 64 sin ese extra.
- Los colores y la tipografía del mockup son **provisionales**: usar los tokens y la fuente que ya tiene la app. Lo que debe copiarse exacto son las medidas y el orden.
- Provisionales del mockup: fondo `#0F0F12`, superficie `#1A1A20`, borde `#3A3A44`, línea `#26262E`, texto `#F4F2EE`, texto secundario `#8C8C98`, acento `#FF5A4E`.

## 1 · Perfil
**Barra superior** (debajo del status bar): alto 48, padding horizontal 8, línea inferior 1.
Izquierda: menú (Recursos) y Amigos. Derecha: tres puntos.

**Cabecera**: padding 4 / 16 / 12 / 16, dos columnas con separación 16.
- Columna izquierda:
  - Avatar **88 × 88**, radio 16, borde 2. Insignia "+" de **28 × 28**, radio 8, borde 2 del color de fondo, desplazada −6 abajo y −6 a la derecha. Al tocar el avatar: agregar stories.
  - Botón **Saldo** 88 × 34, radio 10, borde 1, texto 12 semibold, a 14 debajo del avatar.
  - Botón **Suscripción** igual, a 8 debajo de Saldo.
- Columna derecha (ocupa el resto):
  - Bloque superior con el **mismo alto del avatar (88)**: usuario arriba (16, extra-bold) y fila de contadores **pegada al borde inferior del avatar**.
  - Contadores: 3 columnas iguales, separación 4. Número 18 extra-bold, etiqueta 12 en color secundario. Orden: Me gusta (625), Siguiendo (475), Seguidores (520).
  - **Biografía:** misma columna que el usuario, los contadores y el Enlace: queda **16 a la derecha de los botones Saldo/Suscripción y 16 del borde derecho de la pantalla** (márgenes iguales). Verticalmente, la **parte superior de las letras queda a la altura del borde superior del botón Saldo** (la caja de texto empieza 10 debajo del bloque de usuario y contadores). Misma letra que las etiquetas de los contadores (12 regular, interlineado 16, color secundario). Contraída: máximo 3 líneas con puntos suspensivos. **Al tocarla se despliega** el texto completo (sin límite de líneas, con "Ver menos" al final) y la cabecera crece hacia abajo; el Enlace queda debajo de la biografía. Ver `1b-Perfil-biografia-desplegada.png`.
  - **Enlace**: abajo de la columna, alineado con Suscripción (padding inferior 6), 14 semibold, subrayado, color acento.

**Barra de secciones**: alto 44, padding horizontal 8, líneas arriba y abajo de 1, 6 íconos repartidos con espacio uniforme: cuadrícula (activa, acento), stories, galería, me gusta, guardados, más.

**Cuadrícula de videos**: 3 columnas, separación 2, 2 de padding arriba, tarjetas con proporción 3:4, scroll vertical.
- **Importante:** la última fila visible debe quedar **cortada por la barra inferior**, dejando ver un pedazo de los thumbnails siguientes. Es intencional: indica que hay más videos. No ajustar la altura ni el tamaño de las tarjetas para que quepan filas completas; la altura de la cuadrícula es el espacio que sobra entre la barra de secciones y la barra inferior.

**Barra inferior**: idéntica a la de Amigos (ver punto 6 de `TokVid-medidas-amigos.md`): alto **64 más el safe area inferior**, línea superior de 1, ítems Inicio, Amigos, botón + (52 × 34 con degradado), Mensajes y Perfil con etiquetas de 10.5; **Perfil** activo en rosa.

## 2 · Editar perfil
- Status bar real, luego barra de regreso: alto 56, flecha de 44 × 44 con padding 8.
- Título "Información de perfil": 16 extra-bold, padding horizontal 20, 16 debajo.
- Bloque de foto: padding 0 / 20 / 20 / 20, fila alineada abajo, separación 14.
  - Avatar **128 × 128**, radio 20, borde 2, cámara de 32 centrada.
  - **Cámara del avatar:** sin foto, la cámara (32) va centrada dentro del avatar. **Con foto, la foto llena todo el avatar (recorte cover, radio 20) y la cámara pasa a una insignia de 32 × 32, radio 10, relleno de acento, borde de 2 del color de fondo, desplazada −6 abajo y −6 a la derecha. La cámara nunca debe quedar encima de la foto.** Ver `2b-Editar-perfil-con-foto.png`.
  - A la derecha del avatar (alto 128, igual al avatar, separación 14, ocupa el ancho restante) va una columna con tres acciones: **Guardar** arriba (botón relleno de acento, **alto 36**, radio 18, ancho según su texto con padding horizontal 28, texto 13 bold); y abajo, juntas, **Cambiar foto** (14 semibold, acento, alto 40) y debajo **Recortar foto** (ícono de recorte de 18 + texto 14 semibold, alto 40). Recortar foto abre el recorte de la foto actual.
- Línea de 1. Bloque de datos: padding 16 / 20, separación 14, texto 15 semibold, etiquetas 13 en color secundario: "Nombre: Raúl", "Nombre de usuario" / "tokvid/@usuario".
  - **Descripción (biografía):** campo editable de varias líneas, justo debajo de Nombre de usuario (misma separación de 14). Etiqueta 13 en color secundario, texto 15 semibold con interlineado de 21 y alto mínimo de 3 líneas (63). Si el texto es más largo, el campo crece y la pantalla hace scroll. **Límite: 200 caracteres** (máximo 3 saltos de línea), con contador "34/200" alineado a la derecha debajo del campo, 12 en color secundario.
- Línea de 1. Barra de **Correo (no modificable)**: margen 12 / 20 / 0, alto 48, radio 12, borde 1, padding horizontal 16, texto 15 semibold en color secundario.
- El resto de la pantalla queda libre: "Espacio para futuras implementaciones" centrado, 15, color secundario, sin recuadro.
- Tocar el avatar o "Cambiar foto" abre el modal.

## 3 · Modal de foto
- Fondo oscuro negro al 60 % sobre la pantalla.
- Hoja inferior pegada abajo: radio superior 24, padding 20 / 20 / 32 / 20, separación 8.
- Tres filas de **56 de alto**, radio 12, padding horizontal 16, separación interna 14, ícono 22 + texto 15 semibold: **Cargar foto**, **Tomar foto**, **Ver foto**.

## 4 · Ver foto
- Status bar real, barra de regreso de 56.
- Foto de perfil centrada de **300 × 300**, radio 20, borde 2.

---

## Adaptación a todos los teléfonos (aplica a todas las pantallas)
- Ancho: diseñar para **320 a 412 dp o más**. Alturas fijas, anchos flexibles: lo que se estira son las filas, los campos, el buscador y las cuadrículas. Nada debe cortarse ni salirse de la pantalla.
- Textos largos (nombres, usuarios, etiquetas): una sola línea con puntos suspensivos; nunca empujar botones ni salirse del ancho.
- Letra grande del sistema (por ejemplo, Oppo con Android 12): limitar el escalado de la letra a un máximo de 1.2× y probar con la letra al máximo. Contadores, botones y etiquetas de la barra inferior deben seguir dentro de la pantalla.
- Safe area: arriba la barra de estado real y abajo el espacio de botones o gestos del sistema, en todas las versiones de Android (mínimo Android 10). Esto incluye la hoja del modal: su padding inferior es 32 **más** el safe area inferior.
- Probar con anchos de 320, 360 y 412 dp.

## Instrucción para pegarle a tu agente
Implementa en la app TokVid las pantallas Perfil, Editar perfil, Modal de foto, Ver foto (medidas en `TokVid-medidas-perfil.md`) y Amigos (medidas en `TokVid-medidas-amigos.md`) siguiendo exactamente esas medidas, usando como referencia visual los PNG y el CSS de `referencia/*.html`.
- Respeta medidas, orden y alineaciones tal cual (en especial: contadores alineados con el borde inferior del avatar, botones debajo del status bar real, barra de secciones de 44).
- Usa el tema, los colores y la fuente que ya existen en la app; no copies los colores del mockup.
- Usa el safe area del sistema arriba (status bar) y abajo (botones del teléfono o gestos); no dibujes cámara ni botones del teléfono.
- Solo cambios de interfaz: no modifiques Supabase, migraciones, políticas ni lógica de datos.
- Antes de editar, dime qué archivos vas a tocar; al terminar, compara cada pantalla con el PNG de referencia y lista las diferencias.
