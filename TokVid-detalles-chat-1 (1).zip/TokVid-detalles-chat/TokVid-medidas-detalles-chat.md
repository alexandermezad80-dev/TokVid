# TokVid · Bloque DETALLES DEL CHAT — medidas e instrucciones para el agente

Alcance: SOLO las pantallas "Detalles del chat", "Burbujas del chat" y "Fondo de pantalla". No tocar el chat, Perfil, Feed ni Amigos.
Referencia 390×844 dp; ancho flexible 320–412+ dp. Imágenes: 1-Detalles-chat (pantalla con scroll, alto completo), 2-Burbujas, 3-Fondo-pantalla, Detalles-medidas. HTML exacto en /referencia.
Se mantienen la fuente y los textos que ya usa la app. Estilo CLARO, sobrio y unisex.

## Concepto: sobrio y unisex
La interfaz usa tonos fríos y neutros (azul oscuro #161823, grises y blanco) con el cian como acento principal. El rosa de TokVid queda solo como detalle pequeño (borde del avatar, mini burbuja enviada, texto de burbujas enviadas). No usar fondos ni tintes rosados grandes. Nada de sombras pesadas ni botones grandes.

## Colores
Fondo de pantalla #F4F6F8 · tarjetas blancas #FFFFFF con borde 1 #E9ECEF y sombra mínima 0 1 4 rgba(0,0,0,.03) · texto #0A0A0A · tinta/azul oscuro #161823 (iconos) · texto secundario #737373 · bordes #E5E5E5 · cuadros de icono #EDF0F3 · cian #25F4EE (degradado a teal #0AA9A4 en interruptores) · rosa #FE2C55 (degradado a #D81B60, solo para burbujas enviadas y detalles) · error #EF4444.
Iluminación del fondo: una mancha difuminada cian (opacidad .2) arriba a la izquierda y otra azul grisácea (rgba(70,100,170,.13)) arriba a la derecha, que se desvanecen hacia #F4F6F8 antes de los 330 dp. Sin corte duro.

## 1. Detalles del chat (con scroll)
- Zona segura superior = la del sistema.
- Cabecera 56: atrás 44×44, título 18 bold, menú ⋯ 44×44, transparente sobre la iluminación.
- Hero (avatar a la IZQUIERDA, usuario a su derecha, centrados verticalmente, padding 10 20 20, separación 16): avatar CUADRADO con esquinas redondeadas, 88×88, radio 26, borde degradado cian→rosa de 3 más un borde blanco de 3 por dentro, sombra suave 0 6 18 rgba(22,24,35,.15). Usuario 21 extrabold, una línea con elipsis.
- Acciones rápidas (Crear grupo / Ver perfil / Buscar): 3 botones compactos iguales, 58 de alto, radio 14, fondo blanco, borde 1 #E5E5E5, sin sombra, separación 8, margen lateral 16. Icono 20 (#161823) arriba y etiqueta 12.5 semibold debajo.
- Títulos de sección: 12 bold, mayúsculas, espaciado 0.7, #737373, padding 20 20 8.
- Tarjetas de lista: margen lateral 16, radio 16, filas de 54. Icono 19 #161823 en cuadro 34 radio 10 fondo #EDF0F3 (todos iguales, sin colores por fila); título 15.5 una sola línea; separador 1 #EEF0F2 que empieza a 62 del borde.
  · Personalización: Burbujas del chat (mini burbuja rosa 34×20 + flecha), Fondo de pantalla (miniatura 24×42 del fondo elegido + flecha), Tonos de alerta (flecha).
  · Notificaciones: Silenciar mensajes y Silenciar llamadas con interruptor 46×28; activo = degradado cian→teal, inactivo = #D5D9DE; perilla 24 blanca con sombra.
  · Llamadas: Historial de llamadas, Videollamada.
  · Denunciar: tarjeta aparte; solo aquí se usa color: icono, texto y flecha en #EF4444 (cuadro de icono con tinte rojo).
- Nota final 12.5/17 #737373, padding lateral 24, el mismo texto actual.

## 2. Burbujas del chat
- Arriba: vista previa de 150 de alto, radio 22, con el fondo elegido y 3 mensajes de ejemplo ("¿Vamos hoy?", "Dale, ya salgo", "Te espero") en el estilo elegido; se actualiza al instante al tocar un estilo.
- Debajo, título "Elige un estilo" y cuadrícula de 2 columnas, separación 12, tarjetas de 128 de alto, radio 20. Cada tarjeta muestra una burbuja recibida y una enviada ("Hola") en su estilo y el nombre abajo (14, seleccionado en bold). Radio de tarjetas 16.
- Seleccionada: borde 2 degradado cian→rosa y círculo 22 #161823 con check blanco arriba a la derecha. Se aplica al tocar (sin botón Aplicar).
- Estilos (enviada / recibida, radio):
  · Clásica: degradado #FE2C55→#D81B60, texto blanco / #F0F0F0 · 20
  · Minimalista: blanca con borde 1.5 rosa / blanca con borde 1.5 #E5E5E5 · 12
  · Redonda: rosa sólido / #F0F0F0 · pastilla completa, padding 10×20
  · Cristal: rosa al 14% con borde rosa al 35% / blanca al 70% con borde blanco y sombra suave · 16
  · Degradado: cian→rosa 135°, texto blanco bold con sombra de texto ligera / #F0F0F0 · 20
  · Borde suave: #FFF1F4 con borde rosa 45% / #EFFEFE con borde teal 40% · 18
  · Elegante: negra #0A0A0A, texto blanco / blanca con borde #E5E5E5 · 20
  · Compacta: rosa sólido / #F0F0F0 · radio 8, padding 5×10, texto 12.5
- En el chat real, el estilo elegido se aplica con estos mismos valores; con un fondo de pantalla puesto, las recibidas pasan a blanco con sombra suave (ver bloque de fondos).

## 3. Fondo de pantalla
- Texto de ayuda 14/19 #737373: "Elige cómo se ve esta conversación. Se aplica solo a este chat."
- Cuadrícula de 3 columnas, separación 10 horizontal / 14 vertical, miniaturas de 200 de alto (proporción del teléfono), radio 14, nombre debajo (12.5).
- Fondos: Océano, Neblina, Menta y olas, Geométrico, Ondas, Topográfico, Doodles, Cielo (imágenes del pack TokVid-fondos-chat) y al final "Sin fondo / Liso" (blanco con borde punteado #C9C9D0 e icono de imagen).
- Seleccionado: borde 2.5 degradado cian→rosa y círculo 22 #161823 con check blanco. Se aplica al tocar y se vuelve a la pantalla anterior o se queda; en ambos casos la miniatura de la fila "Fondo de pantalla" se actualiza.

## Adaptación
- 320–412+ dp: los textos no se cortan ni se parten en dos líneas en las filas (una línea, elipsis si hace falta); las cuadrículas mantienen 2 y 3 columnas y las tarjetas se ensanchan.
- Fuente grande del sistema: escala máx. ~1.2x; las tarjetas pueden crecer en alto, nada se recorta.
- Zona segura inferior real (gestos o botones, Android 10+): la lista hace scroll hasta debajo del último elemento más la zona segura.
- Probar a 320 / 360 / 412 dp.

## No hacer
- No añadir opciones nuevas ni cambiar textos.
- No mezclar este bloque con el de Mensajes ni con el de fondos.
